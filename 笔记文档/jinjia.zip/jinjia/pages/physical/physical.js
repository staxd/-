// pages/physical/physical.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentItemId:"0",
    mbList: [{ "mbname": "1"},
    { "mbname": "2"},
     {"mbname": "3"}, 
      { "mbname": "4" }, { "mbname": "5" }, { "mbname": "6" }, { "mbname": "7" }],
    selectIndex: [
      { sureid: false },
      { sureid: false },
      { sureid: false },
      { sureid: false },
      { sureid: false }, { sureid: false }, { sureid: false }
    ]
  },
  selectRep: function (e) {
    let index = e.currentTarget.dataset.selectindex; 
    let selectIndex = this.data.selectIndex;  
    selectIndex[index].sureid = !selectIndex[index].sureid; 
    this.setData({
      selectIndex: selectIndex  
    })

  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})